<?php
// include de arquivos
$paginaAtual = 'Empresa';
include_once './includes/_head.php';#inclui o head da pagina
include_once './includes/_dados.php';#inclui os dados da pagina
include_once './includes/_header.php'#ativa o header da pagina

?>
    <h1>empresa</h1>



<?php
include_once './includes/_footer.php'; #inclui o footer da pagina
?>
